denial-apps
Copyright (C) 2026 Doctor Logix

denial-apps's original source code is free software: you may redistribute it and/or
modify it under the terms of the GNU General Public License as published by the
Free Software Foundation, either version 3 of the License, or (at your option)
any later version.

denial-apps is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
A PARTICULAR PURPOSE. See the GNU General Public License for details.

The complete GNU General Public License version 3 text is included in
LICENSES/GPL-3.0-only.txt. The "or any later version" permission for denial-apps is
granted by this notice.

Bundled third-party components and media remain under their respective
licenses and attribution notices. Their inclusion does not relicense those
works under denial-apps's project license.
